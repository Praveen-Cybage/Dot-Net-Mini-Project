﻿using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    class RegistrationLogin
    {
        private const string SecurityKey = "ComplexKeyHere_12121";
        public static void login(StudentDbContext stuDb)
        {
                try
                {
                    Console.WriteLine("Enter the Email ID");
                    string email = Console.ReadLine();
                    Console.WriteLine("Enter the Pasword");
                    string pass = Console.ReadLine();
                    // StudentDbContext stuDb1 = new StudentDbContext();

                    /*  SqlParameter p1 = new SqlParameter();
                      SqlParameter p2 = new SqlParameter();

                      p1.ParameterName = "@Email_Id";
                      p1.Value =email ;
                      p1.SqlDbType = System.Data.SqlDbType.VarChar;
                      p2.ParameterName = "@password";
                      p2.Value = password;
                      p2.SqlDbType = System.Data.SqlDbType.VarChar;*/
                    // var user = (User)stuDb1.Users.FromSqlRaw("select * from UserTable where Email_ID = @Email_Id ");
                    var users = stuDb.Users.ToList();
                    //plan for Linq
                    User user = null;
                    foreach (User user1 in users)
                    {
                        if ((user1.email == email) && (DecryptCipherTextToPlainText( user1.password) == pass))
                        {
                            user = user1;
                            Console.Write("Login Successfull!!!");
                            break;
                        }

                    }


                    if (user != null)
                    {
                        if (user.role == "Student")
                        {
                            Console.WriteLine("You are in Student Role");
                        StudentController.StudentInfo(stuDb, user);
                        StudentController.UpdateInfo(stuDb, user);
                        
                       
;                        // StudentRole();
                    }
                        else if (user.role == "Teacher")
                        {
                            Console.WriteLine("You are in Teacher Role");
                        // TeacherRole();
                        TeacherController.TeacherInfo(stuDb, user);
                        TeacherController.UpdateInfo(stuDb, user);

                        }
                        else if (user.role == "Admin")
                        {
                            Console.WriteLine("You are in Admin Role");
                            AdminController.AdminRole(stuDb, user);
                        }
                    }

                    else
                    {
                        Console.WriteLine("User Not Found");
                        Console.WriteLine("Please Enter the Details again");
                        login(stuDb);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            
            


        }
        public static void registration(StudentDbContext stuDb)
        {
            // StudentDbContext stuDb = new StudentDbContext();
            try
            {
                User user = new User();
                Console.WriteLine("Please Enter the FirstName");
                user.firstName = Console.ReadLine();

                Console.WriteLine("Please Enter the LastName");
                user.lastName = Console.ReadLine();
                bool flag = false;
                string gender = "";
                do
                {
                    Console.WriteLine("Please Select Gender : 1) Male 2) Female ");
                    int option = Convert.ToInt32(Console.ReadLine());

                    if (option == 1) gender = "Male";
                    else if (option == 2) gender = "Female";
                    else
                    {
                        Console.WriteLine("Please Enter right option");
                        flag = true;
                    }
                } while (flag);

                user.gender = gender;

                Console.WriteLine("Please Enter the Date of Birth in Format of MM/DD/YYYY ");
                user.dob = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Please Enter the Age");
                user.age = Convert.ToInt32(Console.ReadLine());

                //Validation is required (Regex)
                Console.WriteLine("Please Enter the Email Id");
                user.email = Console.ReadLine();

                //Confirm Password validation required
                Console.WriteLine("Please Enter the Password");
                Console.ForegroundColor = ConsoleColor.Black;
                user.password = EncryptPlainTextToCipherText( Console.ReadLine());
                Console.ForegroundColor = ConsoleColor.White;

                //validation required
                Console.WriteLine("Please Enter the Mobile Number");
                user.mobNo = Console.ReadLine();

                Address adds = new Address();
                Console.WriteLine("Enter the Locality");
                adds.locality = Console.ReadLine();

                Console.WriteLine("Enter the City");
                adds.city = Console.ReadLine();

                Console.WriteLine("Enter the State");
                adds.state = Console.ReadLine();

                Console.WriteLine("Enter the Country");
                adds.country = Console.ReadLine();

                //Validation Required
                Console.WriteLine("Enter the PinCode");
                adds.pinCode = Console.ReadLine();

                //Adding the address to the User
                user.Address = adds;

                Console.WriteLine("Please Select Role : 1) Student 2) Teacher 3)Admin");
                int opt = Convert.ToInt32(Console.ReadLine());
                string role = "";
                if (opt == 1)
                {
                    user.role = "Student";
                    Student stu = new Student();

                    //Validation Required
                    Console.WriteLine("Please Enter Standard till 10th");
                    stu.standard = Convert.ToInt32(Console.ReadLine());

                    stu.approval = false;

                    user.student = stu;
                    stuDb.Users.Add(user);
                    stuDb.SaveChanges();


                }
                else if (opt == 2)
                {
                    user.role = "Teacher";
                    Teacher teacher = new Teacher();
                    teacher.approval = false;
                    user.teacher = teacher;
                    stuDb.Users.Add(user);
                    stuDb.SaveChanges();
                }
                //else if is needed
                else if(opt==3)
                {
                    user.role = "Admin";
                    stuDb.Users.Add(user);
                    stuDb.SaveChanges();
                }
                else
                {
                    Console.WriteLine("Please enter valid option number.");
                }
                Console.WriteLine("Registration Successfull");

                //we have implemented do while loop in program.cs file no need of this validation

                Console.WriteLine("Do You want log in(Y/N)?");
                string flag1 = (Console.ReadLine()).ToUpper();
                if (flag1 == "Y")
                {
                    /*Console.WriteLine("Enter the Email ID");
                    string email = Console.ReadLine();
                    Console.WriteLine("Enter the Pasword");
                    string pass = Console.ReadLine();*/

                    login(stuDb);
                }
                else Console.WriteLine("Thank You");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }
        public static string EncryptPlainTextToCipherText(string PlainText)
        {
            // Getting the bytes of Input String.
            byte[] toEncryptedArray = UTF8Encoding.UTF8.GetBytes(PlainText);

            MD5CryptoServiceProvider objMD5CryptoService = new MD5CryptoServiceProvider();
            //Gettting the bytes from the Security Key and Passing it to compute the Corresponding Hash Value.
            byte[] securityKeyArray = objMD5CryptoService.ComputeHash(UTF8Encoding.UTF8.GetBytes(SecurityKey));
            //De-allocatinng the memory after doing the Job.
            objMD5CryptoService.Clear();

            var objTripleDESCryptoService = new TripleDESCryptoServiceProvider();
            //Assigning the Security key to the TripleDES Service Provider.
            objTripleDESCryptoService.Key = securityKeyArray;
            //Mode of the Crypto service is Electronic Code Book.
            objTripleDESCryptoService.Mode = CipherMode.ECB;
            //Padding Mode is PKCS7 if there is any extra byte is added.
            objTripleDESCryptoService.Padding = PaddingMode.PKCS7;


            var objCrytpoTransform = objTripleDESCryptoService.CreateEncryptor();
            //Transform the bytes array to resultArray
            byte[] resultArray = objCrytpoTransform.TransformFinalBlock(toEncryptedArray, 0, toEncryptedArray.Length);
            objTripleDESCryptoService.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        //This method is used to convert the Encrypted/Un-Readable Text back to readable  format.
        public static string DecryptCipherTextToPlainText(string CipherText)
        {
            byte[] toEncryptArray = Convert.FromBase64String(CipherText);
            MD5CryptoServiceProvider objMD5CryptoService = new MD5CryptoServiceProvider();

            //Gettting the bytes from the Security Key and Passing it to compute the Corresponding Hash Value.
            byte[] securityKeyArray = objMD5CryptoService.ComputeHash(UTF8Encoding.UTF8.GetBytes(SecurityKey));
            objMD5CryptoService.Clear();

            var objTripleDESCryptoService = new TripleDESCryptoServiceProvider();
            //Assigning the Security key to the TripleDES Service Provider.
            objTripleDESCryptoService.Key = securityKeyArray;
            //Mode of the Crypto service is Electronic Code Book.
            objTripleDESCryptoService.Mode = CipherMode.ECB;
            //Padding Mode is PKCS7 if there is any extra byte is added.
            objTripleDESCryptoService.Padding = PaddingMode.PKCS7;

            var objCrytpoTransform = objTripleDESCryptoService.CreateDecryptor();
            //Transform the bytes array to resultArray
            byte[] resultArray = objCrytpoTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            objTripleDESCryptoService.Clear();

            //Convert and return the decrypted data/byte into string format.
            return UTF8Encoding.UTF8.GetString(resultArray);
        }





    }
}
