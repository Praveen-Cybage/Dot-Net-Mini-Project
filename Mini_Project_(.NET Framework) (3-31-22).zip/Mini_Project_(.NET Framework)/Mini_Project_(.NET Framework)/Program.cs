﻿using Microsoft.EntityFrameworkCore;
using Mini_Project__.NET_Framework_.Controller;
using Mini_Project__.NET_Framework_.Models;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace Mini_Project__.NET_Framework_
{                              
    class Program
    {

        static void Main(string[] args)
        {
           // Console.WriteLine("Hello World!");
            StudentDbContext stuDb = new StudentDbContext();
             User user = new User();
             Address adds = new Address();
            Student stu = new Student();
            Teacher teacher = new Teacher();

            /* user.firstName = "Pratik";
             user.lastName = "Shinde";
             user.mobNo = "9130960272";
             user.email = "pratik@gmail.com";
             user.password = "pratik@123";
             user.role = "Student";
             user.gender = "Male";

             adds.city = "Nagar";
             adds.country = "India";
             adds.locality = "Kedgaon";
             adds.pinCode = "414005";
             adds.state = "MH";

            /* stu.approval = false;
             stu.div = "A";
             stu.standard = 7;*/

            //Teacher Details
            teacher.designation = "Asistant Teacher";

             user.Address = adds;
            user.teacher = teacher;
            // user.student = stu;

            /*  stuDb.Users.Add(user);
              stuDb.SaveChanges();*/
            /*teacher = stuDb.Teachers.Find(5);
            Console.Write(teacher.approval);*/


            /* User user = stuDb.Users.Find(4);
             stuDb.Users.Remove(user);
             stuDb.SaveChanges();*/

            //Subject

            /* Subject sub = new Subject();
             sub.standard = 8;
             sub.subName = "Science";
             sub.max_marks = 100;
             stuDb.Subjects.Add(sub);
             stuDb.SaveChanges();*/

            Console.WriteLine("Welcome To Student Management System");
            int opt;
            bool flag = true;
            do
            {
                Console.WriteLine("1) Login \n 2) Registrations\n 3) Exit");
                  opt =Convert.ToInt32( Console.ReadLine());
            
                switch(opt)
                {
                    case 1:
                    
                    RegistrationLogin.login(stuDb);
                        break;

                    case 2:
                        RegistrationLogin.registration(stuDb);
                        break;

                    case 3:
                        flag = false;
                        break;

                    default:
                        Console.WriteLine("You have entered wrong choice");
                        break;

                }
                

               // else Console.WriteLine("Please give right options");
            } while (flag);






           
            
        }
       
       
        
    }
}
