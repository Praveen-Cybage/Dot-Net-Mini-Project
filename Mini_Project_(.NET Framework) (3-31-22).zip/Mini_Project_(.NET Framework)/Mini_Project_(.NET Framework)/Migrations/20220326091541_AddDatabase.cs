﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Mini_Project__.NET_Framework_.Migrations
{
    public partial class AddDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    studentID = table.Column<int>(type: "int", nullable: false),
                    Standard = table.Column<int>(type: "int", nullable: false),
                    div = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.studentID);
                    table.ForeignKey(
                        name: "FK_Students_UserTable_studentID",
                        column: x => x.studentID,
                        principalTable: "UserTable",
                        principalColumn: "userID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "StudentSubject",
                columns: table => new
                {
                    StudentsstudentID = table.Column<int>(type: "int", nullable: false),
                    subjectssubjectId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentSubject", x => new { x.StudentsstudentID, x.subjectssubjectId });
                    table.ForeignKey(
                        name: "FK_StudentSubject_Students_StudentsstudentID",
                        column: x => x.StudentsstudentID,
                        principalTable: "Students",
                        principalColumn: "studentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Teachers",
                columns: table => new
                {
                    teacherID = table.Column<int>(type: "int", nullable: false),
                    designation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    subjectId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Teachers", x => x.teacherID);
                    table.ForeignKey(
                        name: "FK_Teachers_UserTable_teacherID",
                        column: x => x.teacherID,
                        principalTable: "UserTable",
                        principalColumn: "userID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Subjects",
                columns: table => new
                {
                    subjectId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    subName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    standard = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    max_marks = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    teacherID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Subjects", x => x.subjectId);
                    table.ForeignKey(
                        name: "FK_Subjects_Teachers_teacherID",
                        column: x => x.teacherID,
                        principalTable: "Teachers",
                        principalColumn: "teacherID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentSubject_subjectssubjectId",
                table: "StudentSubject",
                column: "subjectssubjectId");

            migrationBuilder.CreateIndex(
                name: "IX_Subjects_teacherID",
                table: "Subjects",
                column: "teacherID");

            migrationBuilder.CreateIndex(
                name: "IX_Teachers_subjectId",
                table: "Teachers",
                column: "subjectId",
                unique: true,
                filter: "[subjectId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_StudentSubject_Subjects_subjectssubjectId",
                table: "StudentSubject",
                column: "subjectssubjectId",
                principalTable: "Subjects",
                principalColumn: "subjectId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Teachers_Subjects_subjectId",
                table: "Teachers",
                column: "subjectId",
                principalTable: "Subjects",
                principalColumn: "subjectId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Teachers_Subjects_subjectId",
                table: "Teachers");

            migrationBuilder.DropTable(
                name: "StudentSubject");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Subjects");

            migrationBuilder.DropTable(
                name: "Teachers");
        }
    }
}
