﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Mini_Project__.NET_Framework_.Migrations
{
    public partial class chck : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Teachers_Subjects_subjectId",
                table: "Teachers");

            migrationBuilder.DropIndex(
                name: "IX_Teachers_subjectId",
                table: "Teachers");

            migrationBuilder.DropIndex(
                name: "IX_Subjects_teacherID",
                table: "Subjects");

            migrationBuilder.DropColumn(
                name: "subjectId",
                table: "Teachers");

            migrationBuilder.CreateIndex(
                name: "IX_Subjects_teacherID",
                table: "Subjects",
                column: "teacherID",
                unique: true,
                filter: "[teacherID] IS NOT NULL");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Subjects_teacherID",
                table: "Subjects");

            migrationBuilder.AddColumn<int>(
                name: "subjectId",
                table: "Teachers",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Teachers_subjectId",
                table: "Teachers",
                column: "subjectId",
                unique: true,
                filter: "[subjectId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Subjects_teacherID",
                table: "Subjects",
                column: "teacherID");

            migrationBuilder.AddForeignKey(
                name: "FK_Teachers_Subjects_subjectId",
                table: "Teachers",
                column: "subjectId",
                principalTable: "Subjects",
                principalColumn: "subjectId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
