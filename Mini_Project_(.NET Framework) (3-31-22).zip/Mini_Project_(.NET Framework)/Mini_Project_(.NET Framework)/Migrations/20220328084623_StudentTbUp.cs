﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Mini_Project__.NET_Framework_.Migrations
{
    public partial class StudentTbUp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "makrsObtained",
                table: "Subjects",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "rollNo",
                table: "Students",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "makrsObtained",
                table: "Subjects");

            migrationBuilder.DropColumn(
                name: "rollNo",
                table: "Students");
        }
    }
}
