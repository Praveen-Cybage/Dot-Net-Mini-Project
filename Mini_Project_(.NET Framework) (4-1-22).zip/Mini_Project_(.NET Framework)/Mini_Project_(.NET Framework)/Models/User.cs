﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Models
{
    [Table("UserTable")]
    //[Index(nameof(email, password), IsUnique =true)]
    public class User
    {
        //User table columns

        [Key]
        public int userID { get; set; }

        [Column("First_Name")]
        [MaxLength(15)]
        public string firstName { get; set; }

        [Column("Last_Name")]
        [MaxLength(15)]
        public string lastName { get; set; }

        [Column("Date_Of_Birth", TypeName = "Date")]
        public DateTime dob { get; set; }

        [Column("Mobile_No")]
        [MaxLength(10)]
        public string mobNo { get; set; }

        [Column("Gender")]
        [Required(ErrorMessage ="Gender is Required")]
        public string gender { get; set; }

        [Column("Age")]
        [MaxLength(3)]
        public int age { get; set; }

        [Required(ErrorMessage = "Email Id is required")]
        [Column("Email_ID")]
        [MaxLength(50)]
        public string email { get; set; }

        [Column("Password")]
        [Required]
        [MaxLength(50)]
        public string password { get; set; }

        
        [Column("Roles")]
        [Required(ErrorMessage = "Please Enter your Role")]
        public string role { get; set; }

        //Navigation Properties
        public virtual Address Address { get; set; }
        public virtual Student student { get; set; }
        public virtual Teacher teacher { get; set; }



    }
}
