﻿using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    public class StudentController
    {

        public static void UpdateInfo(StudentDbContext stuDb, User user)
        {
            bool flagUp = true;
            do
            {
                Console.WriteLine("1)Update email\n2)Update Password\n3)Update Mobile No\n4)Update Address\n5)Exit");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        Console.WriteLine("Please enter new Email Id");
                        user.email = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Please enter new Password");
                        user.password = Console.ReadLine();
                        break;
                    case 3:
                        Console.WriteLine("Please enter new Mobile Number");
                        user.mobNo = Console.ReadLine();
                        break;
                    case 4:
                        Console.WriteLine("Please enter new Address");
                        Address add = stuDb.Addresses.Find(user.userID);

                        Console.WriteLine("Enter locality");
                        add.locality = Console.ReadLine();

                        Console.WriteLine("Enter City");
                        add.city = Console.ReadLine();

                        Console.WriteLine("Enter Pincode");
                        add.pinCode = Console.ReadLine();

                        Console.WriteLine("Enter State");
                        add.state = Console.ReadLine();

                        Console.WriteLine("Enter Country");
                        add.country = Console.ReadLine();

                        stuDb.Addresses.Update(add);
                        Console.WriteLine("Updated Successfully");
                        break;
                    case 5:
                        flagUp = false;
                        break;
                    default:
                        Console.WriteLine("Please Enter valid credentials ");
                        break;
                }
            } while (flagUp);

            stuDb.Users.Update(user);
            stuDb.SaveChanges();
            
        }

        public static void StudentInfo(StudentDbContext stuDb, User user)
        {
            Student std = stuDb.Students.Find(user.userID);
            Console.WriteLine(std.rollNo + " " + user.firstName + "   " + user.lastName + "     "+ user.gender + "     " + user.email+ " " + std.standard + " " + std.div);
        }
    }
}
