﻿using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    class RegistrationLogin
    {
        private const string SecurityKey = "ComplexKeyHere_12121";

        public static void login(StudentDbContext stuDb)
        {
            
                try
                {
                    Console.WriteLine("Enter the Email ID");
                    string email = Console.ReadLine();
                    Console.WriteLine("Enter the Pasword");
                    string pass = Console.ReadLine();
                    var users = stuDb.Users.ToList();
                    //plan for Linq
                    User user = null;
                    foreach (User user1 in users)
                    {
                        if ((user1.email == email) && (DecryptCipherTextToPlainText( user1.password) == pass))
                        {
                            user = user1;
                            Console.Write("Login Successfull!!!");
                            break;
                        }

                    }


                    if (user != null)
                    {
                        if (user.role == "Student")
                        {
                            Console.WriteLine("You are in Student Role");
                        StudentController.StudentInfo(stuDb, user);
                        StudentController.UpdateInfo(stuDb, user);
                        
                       
;                        // StudentRole();
                    }
                        else if (user.role == "Teacher")
                        {
                            Console.WriteLine("You are in Teacher Role");
                        // TeacherRole();
                        TeacherController.TeacherInfo(stuDb, user);
                        TeacherController.UpdateInfo(stuDb, user);

                        }
                        else if (user.role == "Admin")
                        {
                            Console.WriteLine("You are in Admin Role");
                            AdminController.AdminRole(stuDb, user);
                        }
                    }

                    else
                    {
                        Console.WriteLine("User Not Found");
                        Console.WriteLine("Please Enter the Details again");
                        login(stuDb);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                }
            
            


        }


        public static void registration(StudentDbContext stuDb)
        {
            string firstName = "";
            string lastName = "";
            string password = "";
            string email = "";
            string gender = "";
            //int mobNo = ;
            //int age = ;
            //StudentDbContext stuDb = new StudentDbContext();
            try
            {
                User user = new User();
                validateFirstName();
                void validateFirstName()
                {
                    Console.WriteLine("Please Enter the FirstName");
                    user.firstName = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(user.firstName) || user.firstName.All(char.IsDigit))
                    {
                        Console.WriteLine("Please enter valid name");
                        validateFirstName();
                    }
                }

                validateLastName();
                void validateLastName()
                { 
                    Console.WriteLine("Please Enter the LastName");
                    user.lastName = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(user.lastName) || user.lastName.All(char.IsDigit))
                    {
                        Console.WriteLine("Please enter valid name");
                        validateLastName();
                    }

                }

                validateEmail();
                void validateEmail()
                {
                    Console.WriteLine("Please Enter the Email Id");
                    user.email = Console.ReadLine();

                    string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";

                    if(!Regex.IsMatch(user.email, pattern))
                    {
                        Console.WriteLine("Please enter a valid Email Id.");
                        validateEmail();
                    }
                }

                validatePassword();
                void validatePassword()
                {
                    string password = "";
                    Console.WriteLine("Please Enter the Password");
                    Console.ForegroundColor = ConsoleColor.Black;
                    user.password = EncryptPlainTextToCipherText(Console.ReadLine());
                    Console.ForegroundColor = ConsoleColor.White;

                    if (string.IsNullOrWhiteSpace(user.password) || user.password.Length < 8)
                    {
                        Console.WriteLine("\n Please enter password with length.");
                        validatePassword();
                }
                

                }

                Console.WriteLine();
                
                bool flag = false;
                
                do
                {
                    Console.WriteLine("Please Select Gender : 1) Male 2) Female ");
                    int option = Convert.ToInt32(Console.ReadLine());

                    if (option == 1) gender = "Male";
                    else if (option == 2) gender = "Female";
                    else
                    {
                        Console.WriteLine("Please Enter right option");
                        flag = true;
                    }
                } while (flag);


                    user.gender = gender;
                
                    
                

                //validateDOB();
                void validateDOB()
                {
                    Console.WriteLine("Please Enter the Date of Birth in Format of DD/MM/YYYY ");
                    user.dob = Convert.ToDateTime(Console.ReadLine());


                    //string result = @"^(3[01] |[12][0 - 9] | 0?[1 - 9]) / (1[0 - 2] | 0?[1 - 9]) / (?:[0 - 9]{ 2})?[0 - 9]{ 2}$";
                    

                    //if (!Regex.IsMatch(user.dob, result);
                    //{
                    //    Console.WriteLine("Please enter a valid DOB.");
                    //    validateDOB();
                    //}

                }


                validateAge();
                void validateAge()
                {
                    Console.WriteLine("Please Enter the valid age");
                    user.mobNo = Console.ReadLine();


                    string result = @"^[1-9][0-9]?$";

                    if (!Regex.IsMatch(user.mobNo, result))
                    {
                        Console.WriteLine("Please enter a valid Age.");
                        validateAge();
                    }

                }         
                

                //validation required


                validateMobile();
                void validateMobile()
                {
                    Console.WriteLine("Please Enter the Mobile Number");
                    user.mobNo = Console.ReadLine();


                    string result = @"^(\+?\d{1,4}[\s-])?(?!0+\s+,?$)\d{10}\s*,?$";

                    if (!Regex.IsMatch(user.mobNo, result))
                    {
                        Console.WriteLine("Please enter a valid Mobile number.");
                        validateMobile();
                    }

                }

                Address adds = new Address();
                Console.WriteLine("Enter the Locality");
                adds.locality = Console.ReadLine();

                Console.WriteLine("Enter the City");
                adds.city = Console.ReadLine();

                Console.WriteLine("Enter the State");
                adds.state = Console.ReadLine();

                Console.WriteLine("Enter the Country");
                adds.country = Console.ReadLine();

                //Validation Required
                

                validatePin();
                void validatePin()
                {
                    Console.WriteLine("Enter the PinCode");
                    adds.pinCode = Console.ReadLine();


                    string result = @"^[1-9]{1}[0-9]{2}\\s{0, 1}[0-9]{3}$";

                    if (!Regex.IsMatch(adds.pinCode, result))
                    {
                        Console.WriteLine("Please enter a valid Pin.");
                        validatePin();
                    }

                }

                try
                {
                    //Adding the address to the User
                    user.Address = adds;
                    bool flagRole = true;
                    do
                    {
                        Console.WriteLine("Please Select Role : 1) Student 2) Teacher 3)Admin");
                        int opt = Convert.ToInt32(Console.ReadLine());
                        string role = "";
                        if (opt == 1)
                        {
                            user.role = "Student";
                            Student stu = new Student();

                            //Validation Required
                            Console.WriteLine("Please Enter Standard till 10th");
                            stu.standard = Convert.ToInt32(Console.ReadLine());

                            stu.approval = false;

                            user.student = stu;


                            stuDb.Users.Add(user);
                            stuDb.SaveChanges();
                            flagRole = false;

                        }
                        else if (opt == 2)
                        {
                            user.role = "Teacher";
                            Teacher teacher = new Teacher();
                            teacher.approval = false;
                            user.teacher = teacher;


                            stuDb.Users.Add(user);
                            stuDb.SaveChanges();
                            flagRole = false;
                        }
                        //else if is needed
                        else if (opt == 3)
                        {
                            user.role = "Admin";
                            stuDb.Users.Add(user);
                            stuDb.SaveChanges();
                            flagRole = false;
                        }
                        else
                        {
                            Console.WriteLine("Please enter valid option number.");
                        }
                    } while (flagRole);
                    Console.WriteLine("Registration Successfull");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                //we have implemented do while loop in program.cs file no need of this validation

                Console.WriteLine("Do You want log in(Y/N)?");
                string flag1 = (Console.ReadLine()).ToUpper();
                if (flag1 == "Y")
                {
                    /*Console.WriteLine("Enter the Email ID");
                    string email = Console.ReadLine();
                    Console.WriteLine("Enter the Pasword");
                    string pass = Console.ReadLine();*/

                    login(stuDb);
                }
                else Console.WriteLine("Thank You");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        


    }

    //public string matchEmail = "\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\b";


        public static string EncryptPlainTextToCipherText(string PlainText)
        {
            // Getting the bytes of Input String.
            byte[] toEncryptedArray = UTF8Encoding.UTF8.GetBytes(PlainText);

            MD5CryptoServiceProvider objMD5CryptoService = new MD5CryptoServiceProvider();
            //Gettting the bytes from the Security Key and Passing it to compute the Corresponding Hash Value.
            byte[] securityKeyArray = objMD5CryptoService.ComputeHash(UTF8Encoding.UTF8.GetBytes(SecurityKey));
            //De-allocatinng the memory after doing the Job.
            objMD5CryptoService.Clear();

            var objTripleDESCryptoService = new TripleDESCryptoServiceProvider();
            //Assigning the Security key to the TripleDES Service Provider.
            objTripleDESCryptoService.Key = securityKeyArray;
            //Mode of the Crypto service is Electronic Code Book.
            objTripleDESCryptoService.Mode = CipherMode.ECB;
            //Padding Mode is PKCS7 if there is any extra byte is added.
            objTripleDESCryptoService.Padding = PaddingMode.PKCS7;


            var objCrytpoTransform = objTripleDESCryptoService.CreateEncryptor();
            //Transform the bytes array to resultArray
            byte[] resultArray = objCrytpoTransform.TransformFinalBlock(toEncryptedArray, 0, toEncryptedArray.Length);
            objTripleDESCryptoService.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        //This method is used to convert the Encrypted/Un-Readable Text back to readable  format.
        public static string DecryptCipherTextToPlainText(string CipherText)
        {
            byte[] toEncryptArray = Convert.FromBase64String(CipherText);
            MD5CryptoServiceProvider objMD5CryptoService = new MD5CryptoServiceProvider();

            //Gettting the bytes from the Security Key and Passing it to compute the Corresponding Hash Value.
            byte[] securityKeyArray = objMD5CryptoService.ComputeHash(UTF8Encoding.UTF8.GetBytes(SecurityKey));
            objMD5CryptoService.Clear();

            var objTripleDESCryptoService = new TripleDESCryptoServiceProvider();
            //Assigning the Security key to the TripleDES Service Provider.
            objTripleDESCryptoService.Key = securityKeyArray;
            //Mode of the Crypto service is Electronic Code Book.
            objTripleDESCryptoService.Mode = CipherMode.ECB;
            //Padding Mode is PKCS7 if there is any extra byte is added.
            objTripleDESCryptoService.Padding = PaddingMode.PKCS7;

            var objCrytpoTransform = objTripleDESCryptoService.CreateDecryptor();
            //Transform the bytes array to resultArray
            byte[] resultArray = objCrytpoTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            objTripleDESCryptoService.Clear();

            //Convert and return the decrypted data/byte into string format.
            return UTF8Encoding.UTF8.GetString(resultArray);
        }





    }
}
