﻿using Mini_Project__.NET_Framework_.Models;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace Mini_Project__.NET_Framework_.Controller
{
    public class RegistrationLogin
    {

        //Security Key for Password Decription
        private const string SecurityKey = "ComplexKeyHere_12121";

        //Method for user login.
        public static void login(StudentDbContext stuDb)
        {
 
            try
            {
                Console.WriteLine("====================================================|\n");
                Console.WriteLine("|***************************************************|");
                //Enter email
                Console.WriteLine("Enter the Email ID");
                Console.CursorLeft = Console.WindowWidth / 8;
                string email = Console.ReadLine();
                Console.WriteLine("|                    *******|");
                //Enter password
                Console.WriteLine("Enter the Pasword");
                Console.CursorLeft = Console.WindowWidth / 8;
                string pass = Console.ReadLine();
                Console.WriteLine("|                    *******|");
                Console.WriteLine("====================================================|\n");

                //Fetching objects of user class from StudentDbContext in users.
                var users = stuDb.Users.ToList();

                //plan for Linq
                User user = null;
                Teacher teach = null;
                Student stu = null;
                
                //Getting all the users list one by one in user1
                foreach (User user1 in users)
                {
                    //Converting password in Decrypted form and checking given email and password with existing data.
                    if ((user1.email == email) && (DecryptCipherTextToPlainText(user1.password) == pass)  )
                    {

                        //creating object according to role
                        //If given role is teacher
                        if (user1.role.Equals("Teacher"))
                        {
                            //Finding userId related to that given perticular user.
                             teach = stuDb.Teachers.Find(user1.userID);

                            //If the teacher is approved by admin
                            if (teach.approval)
                            {
                                user = user1;
                                Console.Clear();
                                Console.WriteLine("|***************************************************|");
                                //Showing info of logged teacher.
                                Console.WriteLine("     Welcome, "+user.firstName + " " + user.lastName);
                                Console.WriteLine("|***************************************************|\n");
                                //Operations given to student.
                                TeacherController.teacherRole(stuDb,user);
                                break;
                            }
                            //If user is not yet approved.
                            else
                                Console.WriteLine("\nUser Not Yet Approved, Please Contact ADMIN");
                            
                        }
                        
                        //If given role is student
                        else if (user1.role.Equals("Student"))
                        {
                            //Finding UserId related to the perticular user.
                             stu = stuDb.Students.Find(user1.userID);

                            //If student is approved
                            if (stu.approval)
                            {
                                user = user1;
                                
                                Console.Clear();
                                Console.WriteLine("|***************************************************|");
                                //Showing info of logged student.
                                Console.WriteLine("     Welcome, " + user.firstName + " " + user.lastName);
                                Console.WriteLine("|***************************************************|\n");

                                //Operations given to student.
                                StudentController.studentRole(stuDb,user);
                                break;
                            }
                            //If user is not yet approved.
                            else
                                Console.WriteLine("\nUser Not Yet Approved, Please Contact ADMIN");

                        }

                        //If user role is admin.
                        else if (user1.role.Equals("Admin"))
                        {
                            user = user1;
                            Console.Clear();
                            Console.WriteLine("|***************************************************|");
                            Console.Write("Login Successfull!!!");
                            Console.WriteLine("\nYou are in ADMIN role");
                            //Showing operations admin can perform.
                            AdminController.AdminRole(stuDb, user);
                            break;
                        }
                        //if user info not found.
                        else
                            Console.WriteLine("\n\nUser Not Found!!!!!");
                    }
                    
                }
          
            }
            //Exception handled.
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }

        }
        //Registration method part.
        //Passing StudentDbContext as parameter, major perpous is memory management. 
        public static void registration(StudentDbContext stuDb)
        {
            try
            {
                //Creating Object of the user class
                User user = new User();

                
                validateFirstName(user);
                //Validation for FirstName
                

                validateLastName(user);
                //Validate LastName
               

                validateEmail(user);
                //Email validation 
               

                validatePassword(user);
                //Password encryption and validation method.
               

                Console.WriteLine();

                bool flag = false;
                string gender = "";
                do
                {

                    //Conditions for Gender selection.
                    Console.WriteLine("|                                        *******|");
                    Console.WriteLine("Please Select Gender : 1) Male 2) Female ");
                    Console.CursorLeft = Console.WindowWidth / 6;
                    int option = Convert.ToInt32(Console.ReadLine());
                    if (option == 1) gender = "Male";
                    else if (option == 2) gender = "Female";
                    else
                    {
                        Console.WriteLine("Please Enter right option");
                        flag = true;
                    }
                } while (flag);


                user.gender = gender;


                validateDOB(user);
                //Method for validating DOB with exception Handling.
             


                validateAge(user);
                //Method for validating age.
                

                validateMobile(user);
                //Validation method for mobile number.
               

                Address adds = new Address();
                Console.WriteLine("|                           **********************|");
                Console.WriteLine("Enter the Locality :");
                Console.CursorLeft = Console.WindowWidth / 6;
                adds.locality = Console.ReadLine();

                Console.WriteLine("|                           **********************|");
                Console.WriteLine("Enter the City :");
                Console.CursorLeft = Console.WindowWidth / 6;
                adds.city = Console.ReadLine();

                Console.WriteLine("|                           **********************|");
                Console.WriteLine("Enter the State :");
                Console.CursorLeft = Console.WindowWidth / 6;
                adds.state = Console.ReadLine();

                Console.WriteLine("|                           **********************|");
                Console.WriteLine("Enter the Country :");
                Console.CursorLeft = Console.WindowWidth / 6;
                adds.country = Console.ReadLine();

                validatePin(adds);
               

                try
                {
                    //Adding the address to the User
                    user.Address = adds;
                    bool flagRole = true;
                    do
                    {
                        Console.WriteLine("|                                                 |");
                        Console.WriteLine("Please Select Role : 1) Student 2) Teacher 3)Admin");
                        Console.CursorLeft = Console.WindowWidth / 6;
                        int opt = Convert.ToInt32(Console.ReadLine());
                        if (opt == 1)
                        {
                            user.role = "Student";
                            Student stu = new Student();

                            //Validation Required
                            Console.WriteLine("|                           **********************|");
                            Console.WriteLine("Please Enter Standard till 10th :");
                            Console.CursorLeft = Console.WindowWidth / 6;
                            stu.standard = Convert.ToInt32(Console.ReadLine());
                            
                            stu.approval = false;

                            user.student = stu;


                            stuDb.Users.Add(user);
                            stuDb.SaveChanges();
                            flagRole = false;

                        }
                        else if (opt == 2)
                        {
                            user.role = "Teacher";
                            Teacher teacher = new Teacher();
                            teacher.approval = false;
                            user.teacher = teacher;


                            stuDb.Users.Add(user);
                            stuDb.SaveChanges();
                            flagRole = false;
                        }
                        //else if is needed
                        else if (opt == 3)
                        {
                            user.role = "Admin";
                            stuDb.Users.Add(user);
                            stuDb.SaveChanges();
                            flagRole = false;
                        }
                        else
                        {
                            Console.WriteLine("Please enter valid option number.");
                        }
                    } while (flagRole);
                    Console.WriteLine("|***************************************************|");
                    Console.WriteLine("Registration Successfull");
                    Console.WriteLine("|***************************************************|\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                //we have implemented do while loop in program.cs file no need of this validation
                Console.Clear();
                Console.WriteLine("|***************************************************|");
                Console.WriteLine("Do You want log in(Y/N)?");
                Console.WriteLine("|***************************************************|\n");
                Console.CursorLeft = Console.WindowWidth / 6;
                string flag1 = (Console.ReadLine()).ToUpper();
                if (flag1 == "Y")
                {
                    
                    login(stuDb);
                }
                else Console.WriteLine("Thank You");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }




        }
       public static void validateFirstName(User user)
        {
            //It will take the user input as firstName.
            Console.WriteLine("|***************************************************|");

            Console.WriteLine("Please Enter the FirstName :");
            Console.CursorLeft = Console.WindowWidth / 6;
            user.firstName = Console.ReadLine();

            //Validation - If null or white spaces is there or If all character in the input is numbers/int. 
            if (string.IsNullOrWhiteSpace(user.firstName) || user.firstName.All(char.IsDigit))
            {
                Console.WriteLine("Please enter valid First_Name");
                //Again it will move to same method
                validateFirstName(user);
            }
        }
       public static void validateLastName(User user)
        {
            //Taking inputs from user as lastName
            Console.WriteLine("|                           **********************|");
            Console.WriteLine("Please Enter the LastName :");
            Console.CursorLeft = Console.WindowWidth / 6;
            user.lastName = Console.ReadLine();

            //Validation - If null or white spaces is there or If all character in the input is numbers/int. 
            if (string.IsNullOrWhiteSpace(user.lastName) || user.lastName.All(char.IsDigit))
            {
                Console.WriteLine("Please enter valid Last_Name");
                //Again it will move to same method
                validateLastName(user);
            }

        }
      public static  void validateEmail(User user)
        {
            //Taking inputs from user as emailID
            Console.WriteLine("|                           **********************|");
            Console.WriteLine("Please Enter the Email Id :");
            Console.CursorLeft = Console.WindowWidth / 6;
            user.email = Console.ReadLine();

            //Regex pattern for checking the valid email address.
            string pattern = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";

            //Checking is the given user email is matching with the regex pattern or not, if it's not get matched
            if (!Regex.IsMatch(user.email, pattern))
            {
                Console.WriteLine("Please enter a valid Email_Id.");
                validateEmail(user);
            }
        }

     public static   void validatePassword(User user)
        {
            Console.WriteLine("|                           **********************|");
            Console.WriteLine("Please Enter the Password :");

            //Hiding the password by converting the console input window for perticular field into black/dark.
            Console.ForegroundColor = ConsoleColor.Black;
            //Here that input password will get encrypted
            Console.CursorLeft = Console.WindowWidth / 6;
            user.password = Console.ReadLine();
            //Again converting that console window to white.
            Console.ForegroundColor = ConsoleColor.White;

            //Validating the password - if user input password is null or taking white spaces 

            string pattern = @"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$";

            //Checking is the given user email is matching with the regex pattern or not, if it's not get matched
            if (!Regex.IsMatch(user.password, pattern))
            {
                Console.WriteLine("\nMinimum eight characters, at least one letter, one number and one special character:");
                validatePassword(user);
            }
            else
                user.password = EncryptPlainTextToCipherText(user.password);


        }
     public static   void validateDOB(User user)
        {
            try
            {
                //If the given data is in correct DOB form
                Console.WriteLine("|                                                |");
                Console.WriteLine("Please Enter the Date of Birth in Format of MM/DD/YYYY :");
                Console.CursorLeft = Console.WindowWidth / 6;
                user.dob = Convert.ToDateTime(Console.ReadLine());
            }
            catch (Exception)
            {
                //If the given data is not in the given form of MM/DD/YYYY
                Console.WriteLine("Please enter DOB in valid given form MM/DD/YYYY");
                validateDOB(user);
            }

        }
      public static  void validateAge(User user)
        {
            //Taking inputs from the user.
            Console.WriteLine("|                           **********************|");
            Console.WriteLine("Please Enter the age :");
            Console.CursorLeft = Console.WindowWidth / 6;
            user.age = Convert.ToInt32(Console.ReadLine());
            //Regex pattern for age
            string pattern = @"^[1-9][0-9]?$";

            //If the given user age is not matching with the regex pattern.
            if (!Regex.IsMatch(user.age.ToString(), pattern))
            {
                Console.WriteLine("Please enter a valid Age.");
                validateAge(user);
            }

        }
     public static   void validateMobile(User user)
        {
            Console.WriteLine("|                           **********************|");
            Console.WriteLine("Please Enter the Mobile Number :");
            Console.CursorLeft = Console.WindowWidth / 6;
            user.mobNo = Console.ReadLine();

            //Regex pattern for mobile number.
            string result = @"^(\+?\d{1,4}[\s-])?(?!0+\s+,?$)\d{10}\s*,?$";

            //If the given user mobile number is not matching with the regex pattern.
            if (!Regex.IsMatch(user.mobNo, result))
            {
                Console.WriteLine("Please enter a valid Mobile number.");
                validateMobile(user);
            }

        }
      public static  void validatePin(Address adds)
        {
            Console.WriteLine("|                           **********************|");
            Console.WriteLine("Enter the PinCode :");
            Console.CursorLeft = Console.WindowWidth / 6;
            adds.pinCode = Console.ReadLine();

            //Regex pattern for pincode - it should contain 6 digits.
            string result = @"^[1-9]{1}[0-9]{2}\s{0,1}[0-9]{3}$";

            //If the given user  is not matching with the regex pattern.
            if (!Regex.IsMatch(adds.pinCode, result))
            {
                Console.WriteLine("Please enter a valid Pin.");
                validatePin(adds);
            }

        }
        //Method for encryption
        public static string EncryptPlainTextToCipherText(string PlainText)
        {
            // Getting the bytes of Input String.
            byte[] toEncryptedArray = UTF8Encoding.UTF8.GetBytes(PlainText);

            MD5CryptoServiceProvider objMD5CryptoService = new MD5CryptoServiceProvider();
            //Gettting the bytes from the Security Key and Passing it to compute the Corresponding Hash Value.
            byte[] securityKeyArray = objMD5CryptoService.ComputeHash(UTF8Encoding.UTF8.GetBytes(SecurityKey));
            //De-allocatinng the memory after doing the Job.
            objMD5CryptoService.Clear();

            var objTripleDESCryptoService = new TripleDESCryptoServiceProvider();
            //Assigning the Security key to the TripleDES Service Provider.
            objTripleDESCryptoService.Key = securityKeyArray;
            //Mode of the Crypto service is Electronic Code Book.
            objTripleDESCryptoService.Mode = CipherMode.ECB;
            //Padding Mode is PKCS7 if there is any extra byte is added.
            objTripleDESCryptoService.Padding = PaddingMode.PKCS7;


            var objCrytpoTransform = objTripleDESCryptoService.CreateEncryptor();
            //Transform the bytes array to resultArray
            byte[] resultArray = objCrytpoTransform.TransformFinalBlock(toEncryptedArray, 0, toEncryptedArray.Length);
            objTripleDESCryptoService.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }

        //Methods for encryption
        //This method is used to convert the Encrypted/Un-Readable Text back to readable  format.
        public static string DecryptCipherTextToPlainText(string CipherText)
        {
            byte[] toEncryptArray = Convert.FromBase64String(CipherText);
            MD5CryptoServiceProvider objMD5CryptoService = new MD5CryptoServiceProvider();

            //Gettting the bytes from the Security Key and Passing it to compute the Corresponding Hash Value.
            byte[] securityKeyArray = objMD5CryptoService.ComputeHash(UTF8Encoding.UTF8.GetBytes(SecurityKey));
            objMD5CryptoService.Clear();

            var objTripleDESCryptoService = new TripleDESCryptoServiceProvider();
            //Assigning the Security key to the TripleDES Service Provider.
            objTripleDESCryptoService.Key = securityKeyArray;
            //Mode of the Crypto service is Electronic Code Book.
            objTripleDESCryptoService.Mode = CipherMode.ECB;
            //Padding Mode is PKCS7 if there is any extra byte is added.
            objTripleDESCryptoService.Padding = PaddingMode.PKCS7;

            var objCrytpoTransform = objTripleDESCryptoService.CreateDecryptor();
            //Transform the bytes array to resultArray
            byte[] resultArray = objCrytpoTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
            objTripleDESCryptoService.Clear();

            //Convert and return the decrypted data/byte into string format.
            return UTF8Encoding.UTF8.GetString(resultArray);
        }





    }
}
