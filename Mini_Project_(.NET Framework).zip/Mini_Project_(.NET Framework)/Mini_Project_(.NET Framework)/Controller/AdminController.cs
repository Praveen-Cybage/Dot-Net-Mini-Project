﻿using Microsoft.EntityFrameworkCore;
using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    class AdminController
    {
        // StudentDbContext stuDb = new StudentDbContext();
        public static void AdminRole(StudentDbContext stuDb,User user)
        {
            try
            {
                List<Student> stuList = stuDb.Students.ToList();
                List<User> userList = stuDb.Users.ToList();
                List<Teacher> teachList = stuDb.Teachers.ToList();
                List<Subject> subList = stuDb.Subjects.ToList();
                bool flag = true;
                do
                {
                    Console.WriteLine("Welcome " + user.firstName);
                    Console.WriteLine("1)Student Information\n2)Teacher Information\n3)Student MarksSheet\n4)Approve Student\n5)Approve Teacher\n6)Add Subject\n7)Assign Subject To Teacher\n8)Exit ");
                    int opt = Convert.ToInt32(Console.ReadLine());
                    switch (opt)
                    {
                        case 1:
                            Console.WriteLine("Student Information");
                            studentInfo(stuDb, stuList, userList);
                            break;

                        case 2:
                            Console.WriteLine("Teacher Information");
                            TeacherInfo(stuDb, teachList, userList);
                            break;

                        case 4:
                            Console.WriteLine("Student Approval");
                            studentApproval(stuDb, stuList, userList);
                            break;
                        case 3:
                            Console.WriteLine("Teacher Approval");
                            teacherApproval(stuDb, teachList, userList, subList);
                            break;
                        case 6:
                            Console.WriteLine("Addming Subjects to the Standard");
                            addSubjects(stuDb, teachList);
                            break;
                        case 7:
                            Console.WriteLine("Assigning Subject to the Teacher");
                            assignSubjectsToTeacher(stuDb, teachList, subList);
                            break;
                        case 8:
                            flag = false;
                            break;


                    }
                } while (flag);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        

        public static void studentInfo(StudentDbContext stuDb, List<Student> stuList, List<User> userList)
        {

            try
            {
                var studentInfo = stuDb.Users.Select(s => s).ToList();
                foreach (Student student in stuList)
                {

                    User user = stuDb.Users.Find(student.studentID);

                    Console.WriteLine(user.firstName + " " + user.lastName + " " + user.gender + " " + user.dob + " " + user.age + " " + user.email);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            

        }

        public static void TeacherInfo(StudentDbContext stuDb, List<Teacher> teachList, List<User> userList)
        {

            try
            {
                var teacherInfo = (stuDb.Users.Select(t => t).ToList()).Cast<Teacher>();
                foreach (Teacher techer in teachList)
                {

                    User user = stuDb.Users.Find(techer.teacherID);

                    Console.WriteLine(user.firstName + " " + user.lastName + " " + user.gender + " " + user.dob + " " + user.age + " " + user.email);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            

        }

        private static void assignSubjectsToTeacher(StudentDbContext stuDb, List<Teacher> teachList, List<Subject> subList)
        {

            //Itrating the subject list for the subject who didnt get any teacher
            try
            {
                foreach (Subject subs in subList)
                {
                    if (subs.teacher == null) Console.WriteLine(subs.subjectId + " " + subs.standard + "    " + subs.subName);
                }
                Console.WriteLine("Please Subject Id from above");
                Subject sub = stuDb.Subjects.Find(Convert.ToInt32(Console.ReadLine()));

                //Itrating teacher list and showing teacher who got the approval
                int count = 0;
                foreach (Teacher teacher in teachList)
                {
                    if (teacher.approval == true)
                    {
                        User user = stuDb.Users.Find(teacher.teacherID);
                        Console.WriteLine(teacher.teacherID + "      " + user.firstName + " " + user.lastName);
                        count++;
                    }
                }

                //checking wheather any teacher present or not
                if (count != 0) Console.WriteLine("Select Teacher which need to assign to this subject");
                else Console.WriteLine("No Teacher Record Found");

                Teacher teach = stuDb.Teachers.Find(Convert.ToInt32(Console.ReadLine()));
                sub.teacher = teach;
                stuDb.Subjects.Update(sub);
                stuDb.SaveChanges();
                Console.WriteLine();
                Console.WriteLine("Teacher has been to the subject");
            
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        private static void addSubjects(StudentDbContext stuDb,List<Teacher>teachList)
        {
            try
            {
                Subject sub = new Subject();

                Console.WriteLine("Please Give the Subject Name");
                sub.subName = Console.ReadLine();

                Console.WriteLine("Please select the standard till 10th in numbers");
                sub.standard = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please Give Maximum Marks for this subject ");
                sub.max_marks = Convert.ToInt32(Console.ReadLine());

                //Itrating teacher list and showing teacher who got the approval
                int count = 0;
                foreach (Teacher teacher in teachList)
                {
                    if (teacher.approval == true)
                    {
                        User user = stuDb.Users.Find(teacher.teacherID);
                        Console.WriteLine(teacher.teacherID + "      " + user.firstName + " " + user.lastName);
                        count++;
                    }
                }

                //checking wheather any teacher present or not
                if (count != 0) Console.WriteLine("Select Teacher which need to assign to this subject");
                else Console.WriteLine("No Teacher Record Found");

                Teacher teach = stuDb.Teachers.Find(Convert.ToInt32(Console.ReadLine()));
                sub.teacher = teach;
                stuDb.Subjects.Add(sub);
                stuDb.SaveChanges();
                Console.WriteLine();
                Console.WriteLine("Subject has been Uploaded in the database");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void studentApproval(StudentDbContext stuDb, List<Student> stuList, List<User> userList)
        {
            try
            {
                //int maxRollNo = 1;
                //var students = stuDb.Students.FromSqlRaw("select * from Students where Admission_Approval = 0 ").ToList();
                Console.WriteLine("Student Id     Student Name      Applied For(STD)      Date of Birth      Address      Approval");
                foreach (Student student in stuList)
                {
                    if (student.approval == false)
                    {
                        User user = stuDb.Users.Find(student.studentID);
                        Address adds = stuDb.Addresses.Find(student.studentID);
                        //Console.WriteLine(user.firstName+user.lastName+student.studentID+student.standard+user.dob+adds.locality);
                        Console.WriteLine(student.studentID + "     " + user.firstName + " " + user.lastName + "      " + student.standard + "      " + user.dob + "      " + adds.city + "      " + student.approval);

                    }
                    //Finding Max Roll No
                  //  if (maxRollNo <= student.rollNo) maxRollNo = student.rollNo + 1;


                }
                //Selecting student admission need to approve

                Console.WriteLine("Select Student Id");
                int stuId = Convert.ToInt32(Console.ReadLine());
                Student stu = stuDb.Students.Find(stuId);


                //Giving Approval
                stu.approval = true;

                //Assigning the Divison to the student
                Console.WriteLine("Enter the Divison from A,B,C,D");
                string div1 = Console.ReadLine();
                stu.div = div1;
                //Finding Last Roll No assignned to Student In perticular div

                int lastRollNo = 1;
                /*SqlParameter p1 = new SqlParameter();
                p1.ParameterName = "@div";
                p1.Value = div;
                p1.SqlDbType = System.Data.SqlDbType.VarChar;
                List<Student> students = stuDb.Students.FromSqlRaw("select * from Students where div=@div ").ToList();*/
                var students = (List<Student>)(stuList.Where(s => s.div == div1)).ToList();
                foreach (Student student in students)
                {
                    if (lastRollNo <= student.rollNo)
                    {
                        lastRollNo = student.rollNo + 1;
                        break;
                    }
                }

                //Assigning Roll No to Student
                stu.rollNo = lastRollNo;
                stuDb.Students.Update(stu);
                stuDb.SaveChanges();

                Console.Write("Student Admission Confirmed");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }    
        }



        public static void teacherApproval(StudentDbContext stuDb, List<Teacher> teacherList, List<User> userList, List<Subject> subList)
        {
            try
            {
                var tech = (from teacher in teacherList
                            where !teacher.approval
                            select teacher).Cast<Teacher>();
                foreach (Teacher teacher in tech)
                {
                    User user = stuDb.Users.Find(teacher.teacherID);
                    Address add = stuDb.Addresses.Find(teacher.teacherID);
                    Console.WriteLine(teacher.teacherID + " " + user.firstName + " " + user.lastName + " " + user.mobNo + " " + add.city);
                }

                Console.WriteLine("Select Teacher Id from above");
                Teacher teach = stuDb.Teachers.Find(Convert.ToInt32(Console.ReadLine()));

                //Giving Approval To student
                teach.approval = true;

                //Assigning Designation to the Teacher
                Console.WriteLine("Select the Designation \n    1)Asistant Teacher\n     2) Teacher\n     3)HOD");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        teach.designation = "Asistant Teacher";
                        break;
                    case 2:
                        teach.designation = "Teacher";
                        break;
                    case 3:
                        teach.designation = "HOD";
                        break;

                }

                //Adding the subject object to the subject databases*/
                stuDb.Teachers.Update(teach);

                //  Saving the changes
                stuDb.SaveChanges();

            }
            
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }
    }
}
