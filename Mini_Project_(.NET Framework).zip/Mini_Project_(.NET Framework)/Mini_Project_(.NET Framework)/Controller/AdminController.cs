﻿using Microsoft.EntityFrameworkCore;
using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    class AdminController
    {
        public static void AdminRole(StudentDbContext stuDb, User user)
        {
            try
            {
                List<Student> stuList = stuDb.Students.ToList();
                List<User> userList = stuDb.Users.ToList();
                List<Teacher> teachList = stuDb.Teachers.ToList();
                List<Subject> subList = stuDb.Subjects.ToList();
                bool flag = true;
                do
                {
                    Console.WriteLine("Welcome " + user.firstName +" "+ user.lastName);
                    Console.WriteLine("|------------------------|");
                    Console.WriteLine("1)Student Information\n" +
                        "\n2)Teacher Information\n" +
                        "\n3)User Profile updation\n" +
                        "\n4)Approve Teacher\n" +
                        "\n5)Approve Student\n" +
                        "\n6)Add Subject\n" +
                        "\n7)Assign Subject To Teacher\n" +
                        "\n8)Update Your Profile\n" +
                        "\n9)Delete Profile\n" +
                        "\n0)Exit ");
                    Console.WriteLine("|************************************************|");
                    int opt = Convert.ToInt32(Console.ReadLine());
                    switch (opt)
                    {
                        case 1:
                            Console.WriteLine("\n\nStudent Information");
                            studentInfo(stuDb, stuList, userList);
                            break;

                        case 2:
                            Console.WriteLine("\n\nTeacher Information");
                            TeacherInfo(stuDb, teachList, userList);
                            break;

                        case 3:
                            Console.WriteLine("\n\nStudent Marksheet");
                            userProfileUpdation(stuDb, teachList, userList, stuList);
                            break;

                        case 4:
                            Console.WriteLine("\n\nTeacher Approval");
                            teacherApproval(stuDb, teachList, userList, subList);
                            break;

                        case 5:
                            Console.WriteLine("\n\nStudent Approval");
                            studentApproval(stuDb, stuList, userList);
                            break;

                        case 6:
                            Console.WriteLine("\n\nAddming Subjects to the Standard");
                            addSubjects(stuDb, teachList);
                            break;

                        case 7:
                            Console.WriteLine("\n\nAssigning Subject to the Teacher");
                            assignSubjectsToTeacher(stuDb, teachList, subList);
                            break;

                        case 8:
                            Console.WriteLine("\n\nUpdate Your Profile");
                            updateProfile(stuDb, user);
                            break;

                        case 9:
                            Console.WriteLine("\n\nDelete Profile");
                            deleteProfile(stuDb, userList, user);
                            break;

                        case 0:
                            flag = false;
                            break;
                        default:
                            Console.WriteLine("\nPlease select right option from the above ");
                            break;

                    }
                } while (flag);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        //Method For User Specific Profile Updation
        private static void userProfileUpdation(StudentDbContext stuDb, List<Teacher> teachList, List<User> userList, List<Student> stuList)
        {
            try
            {
                bool flaguser = true;
                do
                {
                    Console.WriteLine("\n|********************************************************************************|");
                    Console.WriteLine("1)Update Student"+"      "+"2)Update Teacher"+"      "+"3) Exit");
                    Console.WriteLine("|********************************************************************************|\n");
                    switch (Convert.ToInt32(Console.ReadLine()))
                    {
                        case 1:
                            User user = null;
                            user = approvedStudentList(stuList, stuDb);
                            if (user != null)
                            {
                                //Updating User as well as address Functionality
                                updateProfile(stuDb, user);
                            }
                            else Console.WriteLine("\nUser Not found!!!!");
                            break;

                        case 2:
                            User teachUser = null;
                            //Getting teacher object who is approved
                            user = approvedTeacherList(teachList, stuDb);

                            if (teachUser != null)
                            {
                                //Updating User as well as address Functionality
                                updateProfile(stuDb, teachUser);
                            }
                            else Console.WriteLine("\n\nUser Not found!!!!");

                            break;

                        case 3:
                            flaguser = false;
                            break;

                        default:
                            Console.WriteLine("\n\nPlease enter the right option!!!!!");
                            break;

                    }

                } while (flaguser);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        //Method for Updating user Basic Information
        public static void updateProfile(StudentDbContext stuDb, User user)
        {
            try
            {
                //Update basic information
                userUpdate(stuDb, user);
                if (user.role == "Student")
                {

                    Student stu = stuDb.Students.Find(user.userID);
                    Console.WriteLine("\n\nPlease enter Standard till 10th");
                    stu.standard = Convert.ToInt32(Console.ReadLine());

                    bool flagDiv = true;
                    do
                    {
                        Console.WriteLine("\n\nPlease enter the division  \n1)A\n2)B\n3)C\n4)Exit");
                        switch (Convert.ToInt32(Console.ReadLine()))
                        {
                            case 1:
                                stu.div = "A";
                                break;
                            case 2:
                                stu.div = "A";
                                break;
                            case 3:
                                stu.div = "A";
                                break;
                            case 4:
                                flagDiv = false;
                                break;
                            default:
                                Console.WriteLine("\n\nPlease Enter appropriate option from above!!!");
                                break;
                        }

                    } while (flagDiv);

                    //Saving Infromation
                    stuDb.Students.Update(stu);

                }
                else if (user.role == "Teacher")
                {
                    Teacher teacher = stuDb.Teachers.Find(user.userID);
                    bool flagteach = true;
                    do
                    {

                        Console.WriteLine("Select the Designation \n    1)Asistant Teacher\n     2) Teacher\n     3)HOD\n4)Exit");
                        switch (Convert.ToInt32(Console.ReadLine()))
                        {
                            case 1:
                                teacher.designation = "Asistant Teacher";
                                break;
                            case 2:
                                teacher.designation = "Teacher";
                                break;
                            case 3:
                                teacher.designation = "HOD";
                                break;
                            case 4:
                                flagteach = false;
                                break;
                            default:
                                Console.WriteLine("\n\n Please Enter Appropriate Option from the above");
                                break;

                        }
                    } while (flagteach);

                    //Updating the information
                    stuDb.Teachers.Update(teacher);

                }
                //Updating parent class
                stuDb.Users.Update(user);
                stuDb.SaveChanges();
                Console.WriteLine("\n\nProfile Updated Successfully.");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void deleteProfile(StudentDbContext stuDb, List<User> userList, User user)
        {
            try
            {
                Console.WriteLine("\n\nEnter ID for deleting records of Student/Teacher: ");
                int id = Convert.ToInt32(Console.ReadLine());

                var obj = stuDb.Users.Find(id);
                stuDb.Users.Remove(obj);

                stuDb.SaveChanges();
                Console.WriteLine("\n\n" + obj.firstName + " " + obj.lastName + " Deletion Successful!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void studentInfo(StudentDbContext stuDb, List<Student> stuList, List<User> userList)
        {
            try
            {

                User user = approvedStudentList(stuList, stuDb);
                if (user != null)
                {

                    Console.WriteLine(user.firstName + " " + user.lastName + " " + user.gender + " " + user.dob + " " + user.age + " " + user.email);
                }
                else
                    Console.WriteLine("\n\nUser not found!!!!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void TeacherInfo(StudentDbContext stuDb, List<Teacher> teachList, List<User> userList)
        {

            try
            {

                User user = approvedTeacherList(teachList, stuDb);
                if (user != null)
                {
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------|");
                    Console.WriteLine("\n|FirstName|" + " " + " " + "|LastName|" + " " + " |Gender|" + "  " + "    |Email|" + "    " + "  |Age|" + "    " + "|DOB|");
                    Console.WriteLine(user.firstName + " " + user.lastName + " " + user.gender + " " + user.email + " " + user.age + " " + user.dob);
                    Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------|");
                }
                else
                    Console.WriteLine("\n\nUser not found!!!!");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void assignSubjectsToTeacher(StudentDbContext stuDb, List<Teacher> teachList, List<Subject> subList)
        {

            //Itrating the subject list for the subject who didnt get any teacher
            try
            {
                foreach (Subject subs in subList)
                {
                    if (subs.teacher == null) Console.WriteLine(subs.subjectId + " " + subs.standard + "    " + subs.subName);
                }
                Console.WriteLine("\n\nPlease Subject Id from above");
                Subject sub = stuDb.Subjects.Find(Convert.ToInt32(Console.ReadLine()));

                //Itrating teacher list and showing teacher who got the approval
                User user = approvedTeacherList(teachList, stuDb);

                //checking weather any teacher present or not
                if (user != null)
                {
                    Teacher teach = stuDb.Teachers.Find(user.userID);
                    sub.teacher = teach;
                    stuDb.Subjects.Update(sub);
                    stuDb.SaveChanges();
                    Console.WriteLine();
                    Console.WriteLine("\n\nTeacher has been assigned to the subject");
                }
                else Console.WriteLine("\n\nNo Teacher Record Found");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void addSubjects(StudentDbContext stuDb, List<Teacher> teachList)
        {
            try
            {
                Subject sub = new Subject();

                Console.WriteLine("Please Give the Subject Name");
                sub.subName = Console.ReadLine();

                Console.WriteLine("Please select the standard till 10th in numbers");
                sub.standard = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please Give Maximum Marks for this subject ");
                sub.max_marks = Convert.ToInt32(Console.ReadLine());
                stuDb.Subjects.Add(sub);
                stuDb.SaveChanges();
                Console.WriteLine();
                Console.WriteLine("Subject has been Uploaded in the database");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public static void studentApproval(StudentDbContext stuDb, List<Student> stuList, List<User> userList)
        {
            try
            {
                int count = 0;
                Console.WriteLine("\nStudent Id     Student Name      Applied For(STD)      Date of Birth      Address      Approval");
                foreach (Student student in stuList)
                {
                    if (student.approval == false)
                    {
                        User user = stuDb.Users.Find(student.studentID);
                        Address adds = stuDb.Addresses.Find(student.studentID);
                        Console.WriteLine(student.studentID + "     " + user.firstName + " " + user.lastName + "      " + student.standard + "      " + user.dob + "      " + adds.city + "      " + student.approval);
                        count++;
                    }
                    
                }
                //Selecting student admission need to approve
                if (count > 0)
                {
                    Console.WriteLine("Select Student Id");
                    int stuId = Convert.ToInt32(Console.ReadLine());
                    Student stu = stuDb.Students.Find(stuId);


                    //Giving Approval
                    stu.approval = true;

                    //Assigning the Divison to the student
                    Console.WriteLine("\nEnter the Divison from A,B,C,D");
                    string div1 = Console.ReadLine();
                    stu.div = div1;
                    //Finding Last Roll No assignned to Student In perticular div

                    int lastRollNo = 1;
                     var students = (List<Student>)(stuList.Where(s => s.div == div1)).ToList();
                    foreach (Student student in students)
                    {
                        if (lastRollNo <= student.rollNo)
                        {
                            lastRollNo = student.rollNo + 1;
                            break;
                        }
                    }

                    //Assigning Roll No to Student
                    stu.rollNo = lastRollNo;
                    stuDb.Students.Update(stu);
                    stuDb.SaveChanges();

                    Console.Write("Student Admission Confirmed");
                    
                }
                else Console.WriteLine("\n There is no student present for Approval");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }

        public static void teacherApproval(StudentDbContext stuDb, List<Teacher> teacherList, List<User> userList, List<Subject> subList)
        {
            try
            {
                
                var tech = (from teacher in teacherList
                            where !teacher.approval
                            select teacher).Cast<Teacher>();
                int count = tech.Count();
                if (count > 0)
                {
                    foreach (Teacher teacher in tech)
                    {
                        User user = stuDb.Users.Find(teacher.teacherID);
                        Address add = stuDb.Addresses.Find(teacher.teacherID);
                        Console.WriteLine(teacher.teacherID + " " + user.firstName + " " + user.lastName + " " + user.mobNo + " " + add.city);
                    }

                    Console.WriteLine("Select Teacher Id from above");
                    int techID = Convert.ToInt32(Console.ReadLine());
                    Teacher teach = null;
                    teach = stuDb.Teachers.Find(techID);

                    if (teach != null)
                    {

                        //Giving Approval To student
                        teach.approval = true;
                        Console.WriteLine("approved!!!!");
                        //Assigning Designation to the Teacher
                        Console.WriteLine("Select the Designation \n    1)Asistant Teacher\n     2) Teacher\n     3)HOD");
                        switch (Convert.ToInt32(Console.ReadLine()))
                        {
                            case 1:
                                teach.designation = "Asistant Teacher";
                                break;
                            case 2:
                                teach.designation = "Teacher";
                                break;
                            case 3:
                                teach.designation = "HOD";
                                break;

                        }
                        //Adding the subject object to the subject databases*/
                        stuDb.Teachers.Update(teach);

                        //  Saving the changes
                        stuDb.SaveChanges();
                    }
                    
                }
                else
                {
                    Console.WriteLine("No teacher found for approval");
                }
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void userUpdate(StudentDbContext stuDb, User user)
        {
            bool flagUp = true;
            do
            {
                Console.WriteLine("\n1)Update email\n2)Update Password\n3)Update Mobile No\n4)Update Address\n5)Exit");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        Console.WriteLine("Please enter new Email Id");
                        user.email = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Please enter new Password");
                        Console.ForegroundColor = ConsoleColor.Black;
                        user.password = RegistrationLogin.EncryptPlainTextToCipherText(Console.ReadLine());
                        Console.ForegroundColor = ConsoleColor.White;
                        user.password = Console.ReadLine();
                        break;
                    case 3:
                        Console.WriteLine("Please enter new Mobile Number");
                        user.mobNo = Console.ReadLine();
                        break;
                    case 4:
                        Console.WriteLine("Please enter new Address");
                        Address add = stuDb.Addresses.Find(user.userID);

                        Console.WriteLine("Enter locality");
                        add.locality = Console.ReadLine();

                        Console.WriteLine("Enter City");
                        add.city = Console.ReadLine();

                        Console.WriteLine("Enter Pincode");
                        add.pinCode = Console.ReadLine();

                        Console.WriteLine("Enter State");
                        add.state = Console.ReadLine();

                        Console.WriteLine("Enter Country");
                        add.country = Console.ReadLine();

                        stuDb.Addresses.Update(add);
                        break;
                    case 5:
                        flagUp = false;
                        break;
                    default:
                        Console.WriteLine("Please Enter valid credentials ");
                        break;
                }
            } while (flagUp);
        }

        public static User approvedStudentList(List<Student> stuList, StudentDbContext stuDb)
        {

            foreach (Student stu in stuList)
            {
                if (stu.approval)
                {
                    User stuUser = stuDb.Users.Find(stu.studentID);
                    Console.WriteLine("\n" + stu.studentID + "     " + stuUser.firstName + " " + stuUser.lastName + "   " + stu.standard);

                }
            }
            Console.WriteLine("Please enter the user ID");
            User user = stuDb.Users.Find(Convert.ToInt32(Console.ReadLine()));
            return user;
        }
        public static User approvedTeacherList(List<Teacher> stuList, StudentDbContext stuDb)
        {
            List<Teacher> filteredList = (List<Teacher>)stuDb.Teachers.Where(s => s.approval == true);
            foreach (Teacher teach in filteredList)
            {
                User stuUser = stuDb.Users.Find(teach.teacherID);
                Console.WriteLine("\n" + teach.teacherID + "     " + stuUser.firstName + " " + stuUser.lastName + "   " + teach.designation);
            }
            Console.WriteLine("\nPlease enter the user ID");
            User user = stuDb.Users.Find(Convert.ToInt32(Console.ReadLine()));
            return user;
        }
    }
}
