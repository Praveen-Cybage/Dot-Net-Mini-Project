﻿using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    class TeacherController
    {
        

        public static void teacherRole(StudentDbContext stuDb)
        {
            List<Student> stuList = stuDb.Students.ToList();
            assignMarksToStudent(stuDb);
        }
        public static void assignMarksToStudent(StudentDbContext stuDb)
        {
            
        }
    }
   
}
