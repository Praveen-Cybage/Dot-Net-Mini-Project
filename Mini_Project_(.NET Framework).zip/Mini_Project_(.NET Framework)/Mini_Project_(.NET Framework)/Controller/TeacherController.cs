﻿using Mini_Project__.NET_Framework_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Controller
{
    class TeacherController
    {


        public static void teacherRole(StudentDbContext stuDb, User user)
        {
            Console.WriteLine();
            Console.WriteLine("\nWelcome " + user.firstName);
            bool flag = true;
            do
            {
                Console.WriteLine("\n|********************************************************************************|");
                Console.WriteLine(" 1)TECHER INFORMATION" + "        " + " 2)UPDATE INFORMATION" + "         " + " 3)EXIT");
                Console.WriteLine("|********************************************************************************|\n");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        teacherInfo(stuDb, user);
                        break;

                    case 2:
                        updateInfo(stuDb, user);
                        break;

                    case 3:
                        flag = false;
                        break;

                    default:
                        Console.WriteLine("Please choose correct choice!!!!");
                        break;

                }
            } while (flag);
        }
        public static void updateInfo(StudentDbContext stuDb, User user)
        {
            bool flagUp = true;
            do
            {
                Console.WriteLine("\n|******************************************************************************************************************|");
                Console.WriteLine("1)Update_Email" + "    " + "2)Update_Password" + "    " + "3)Update_Mobile-No" + "   " + "4)Update_Address" + "     " + "5)Exit");
                Console.WriteLine("|********************************************************************************************************************|\n");
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        Console.WriteLine("Please enter new Email Id");
                        user.email = Console.ReadLine();
                        break;
                    case 2:
                        Console.WriteLine("Please enter new Password");
                        Console.ForegroundColor = ConsoleColor.Black;
                        user.password = RegistrationLogin.EncryptPlainTextToCipherText(Console.ReadLine());
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                    case 3:
                        Console.WriteLine("Please enter new Mobile Number");
                        user.mobNo = Console.ReadLine();
                        break;
                    case 4:
                        Console.WriteLine("Please enter new Address");
                        Address add = stuDb.Addresses.Find(user.userID);

                        Console.WriteLine("Enter locality");
                        add.locality = Console.ReadLine();

                        Console.WriteLine("Enter City");
                        add.city = Console.ReadLine();

                        Console.WriteLine("Enter Pincode");
                        add.pinCode = Console.ReadLine();

                        Console.WriteLine("Enter State");
                        add.state = Console.ReadLine();

                        Console.WriteLine("Enter Country");
                        add.country = Console.ReadLine();

                        stuDb.Addresses.Update(add);
                        Console.WriteLine("Updated Successfully");
                        break;
                    case 5:
                        flagUp = false;
                        break;
                    default:
                        Console.WriteLine("Please Enter valid credentials ");
                        break;
                }
            } while (flagUp);

            stuDb.Users.Update(user);
            stuDb.SaveChanges();
            
        }

        public static void teacherInfo(StudentDbContext stuDb, User user)
        {
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------|");
            Console.WriteLine("\n|User_ID|" + " " + "|FirstName|" + " " + " " + "|LastName|" + " " + " |Gender|" + "  " + "    |Email|" + "    " + "  |Designation|" + "        " + "|ID|");
            Teacher teach = stuDb.Teachers.Find(user.userID);
            string strFormatRow = String.Format(user.userID + "           " + user.firstName + "      " + user.lastName + "       " + user.gender + "      " + user.email + "       " + teach.designation + "        " + teach.teacherID);
            Console.WriteLine(strFormatRow);
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------|");
            
        }
}
   
}
