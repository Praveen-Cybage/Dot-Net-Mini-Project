﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mini_Project__.NET_Framework_.Models
{
    [Table("UserTable")]
    public class User
    {
        //User table columns

        [Key]
        public int userID { get; set; }

        [Column("First_Name")]
        [MaxLength(15)]
        public string firstName { get; set; }

        [Column("Last_Name")]
        [MaxLength(15)]
        public string lastName { get; set; }

        [Column("Date_Of_Birth", TypeName = "Date")]
        [RegularExpression(@"(\d{2}/\d{2}/\d{4})", ErrorMessage = "Please enter a valid Date (MM/DD/YYYY)")]
        public DateTime dob { get; set; }

        [Column("Mobile_No")]
        [MaxLength(10)]
        public string mobNo { get; set; }

        [Column("Gender")]
        [Required(ErrorMessage ="Gender is Required")]
        public string gender { get; set; }

        [Column("Age")]
        [MaxLength(3)]
        public int age { get; set; }

        [Column("Email_ID")]
        [Required(ErrorMessage = "Email id is required")]
        [RegularExpression(@"\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b",
                            ErrorMessage = "Please enter a valid email address")]
        [MaxLength(20)]
        public string email { get; set; }

        [Column("Password")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$", 
            ErrorMessage = "Password must be between 6 and 20 characters and contain one uppercase letter, one lowercase letter, one digit and one special character.")]
        [MaxLength(50)]
        public string password { get; set; }

        [Column("Roles")]
        [Required(ErrorMessage = "Please Enter your Role")]
        public string role { get; set; }

        //Navigation Properties
        public virtual Address Address { get; set; } //One to One relationship
        public virtual Student student { get; set; } //One to One relationship
        public virtual Teacher teacher { get; set; } //One to One relationship





    }
}
