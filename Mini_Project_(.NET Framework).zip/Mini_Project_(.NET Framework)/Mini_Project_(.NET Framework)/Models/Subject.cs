﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Mini_Project__.NET_Framework_.Models
{
    public class Subject
    {
        [Key]
        public int subjectId { get; set; }

        [Column("SubjectName")]
        public string subName { get; set; }

        [Column("Standard")]
        public int standard { get; set; }

        [Column("MaximumMarks")]
        public int max_marks { get; set; }


        //Navigation Properties
        public virtual ICollection<Student> Students { get; set; } //Many To Many Relationship

        //[ForeignKey("teacherID")]
        public  Teacher teacher { get; set; }  //One to Many RelationShip
    }
}
