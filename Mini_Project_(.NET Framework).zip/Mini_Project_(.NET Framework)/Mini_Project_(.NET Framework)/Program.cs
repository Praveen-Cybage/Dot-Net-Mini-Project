﻿using Microsoft.EntityFrameworkCore;
using Mini_Project__.NET_Framework_.Controller;
using Mini_Project__.NET_Framework_.Models;
using System;
using System.Data.SqlClient;
using System.Linq;

namespace Mini_Project__.NET_Framework_
{                              
    class Program
    {

        static void Main(string[] args)
        {
            StudentDbContext stuDb = new StudentDbContext();
            int opt;
            bool flag = true;
            do
            {
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                string title = @"
 _____  _               _               _    ___  ___                                                           _     _____              _                    
/  ___|| |             | |             | |   |  \/  |                                                          | |   /  ___|            | |                   
\ `--. | |_  _   _   __| |  ___  _ __  | |_  | .  . |  __ _  _ __    __ _   __ _   ___  _ __ ___    ___  _ __  | |_  \ `--.  _   _  ___ | |_   ___  _ __ ___  
 `--. \| __|| | | | / _` | / _ \| '_ \ | __| | |\/| | / _` || '_ \  / _` | / _` | / _ \| '_ ` _ \  / _ \| '_ \ | __|  `--. \| | | |/ __|| __| / _ \| '_ ` _ \ 
/\__/ /| |_ | |_| || (_| ||  __/| | | || |_  | |  | || (_| || | | || (_| || (_| ||  __/| | | | | ||  __/| | | || |_  /\__/ /| |_| |\__ \| |_ |  __/| | | | | |
\____/  \__| \__,_| \__,_| \___||_| |_| \__| \_|  |_/ \__,_||_| |_| \__,_| \__, | \___||_| |_| |_| \___||_| |_| \__| \____/  \__, ||___/ \__| \___||_| |_| |_|
                                                                            __/ |                                             __/ |                           
                                                                           |___/                                             |___/                            
";
                Console.Clear();
                Console.WriteLine(title);
                Console.ResetColor();
                Console.WriteLine("|***************************************************|");
                Console.WriteLine("         1) LOGIN   2) REGISTER   3) EXIT");
                Console.WriteLine("|***************************************************|");
                Console.CursorLeft = Console.WindowWidth / 6;
                opt =Convert.ToInt32( Console.ReadLine());
            
                switch(opt)
                {
                    case 1:
                    
                    RegistrationLogin.login(stuDb);
                        break;

                    case 2:
                        RegistrationLogin.registration(stuDb);
                        break;

                    case 3:
                        flag = false;
                        break;

                    default:
                        Console.WriteLine("You have entered wrong choice");
                        break;

                }
                

               // else Console.WriteLine("Please give right options");
            } while (flag);
         
        }
         
    }
}
